from django.db import models

# Create your models here.
from django.db import models

class Order(models.Model):
    product_name = models.CharField(max_length=100)
    delivery_time = models.DurationField()
    
    def __str__(self):
        return self.product_name

    @classmethod
    def average_delivery_time(cls):
        return cls.objects.aggregate(models.Avg('delivery_time'))['delivery_time__avg']