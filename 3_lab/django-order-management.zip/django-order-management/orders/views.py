from django.shortcuts import render

# Create your views here.
from .models import Order

def order_list(request):
    orders = Order.objects.all()
    avg_delivery_time = Order.average_delivery_time()
    return render(request, 'orders/order_list.html', {'orders': orders, 'avg_delivery_time': avg_delivery_time})